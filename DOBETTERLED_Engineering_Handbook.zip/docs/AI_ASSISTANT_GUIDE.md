# DOBETTERLED AI Assistant Guide

## Purpose

This document is for ChatGPT, Claude, GitHub Copilot, Cursor, or any other AI assistant helping with DOBETTERLED.

Read this before generating code.

## Project Summary

DOBETTERLED is an ESP32 PlatformIO firmware platform for festival LEDs, totems, flow art, wearables, and future LED products.

Current stable baseline:

- PlatformIO project works
- Dig2Go hardware confirmed
- 15 WS2812B LEDs confirmed
- GPIO16 data
- GPIO12 relay
- GRB color order
- Bring-Up Dashboard works

## Development Rules

1. Do not generate large code dumps.
2. Work one subsystem at a time.
3. Preserve the Bring-Up Dashboard.
4. Never remove a known-good hardware test.
5. Prefer PlatformIO over Arduino IDE.
6. Do not add feature creep before Beta 1.
7. Explain code changes simply and visually.
8. After every change: build, upload, test, commit.
9. If LED output fails, return to the dashboard.
10. Keep the tone practical, direct, and maker-friendly.

## Current Next Milestone

v0.2.0-alpha — Interactive Bring-Up Dashboard

Focus on:

- physical button diagnostics
- raw state display
- click event display
- hold duration
- brightness ramp testing
- factory reset warning behavior

## Architecture Rules

- HAL owns low-level hardware access only.
- LEDDriver owns FastLED only.
- ButtonManager emits events only.
- SystemManager maps events to actions.
- SettingsManager owns persistent state only.
- Effects never touch hardware.
- PaletteManager stays stateless.
- SoundManager outputs processed audio values, not raw mic details.

## Code Style

- Use clear filenames.
- Use comments for intent, not obvious syntax.
- Avoid delay() except in dedicated diagnostics.
- Use millis()-based timing for runtime features.
- Avoid global state unless required for hardware library integration.
- Make every subsystem testable.

## Response Style for Jesse

Jesse prefers:

- visual explanations
- simple step-by-step instructions
- practical debugging
- honest assessment
- no unnecessary jargon
- project/product thinking
- snarky but useful humor when appropriate

## Golden Rule

Do not make DOBETTERLED more complex until the current hardware milestone works on the real Dig2Go.
