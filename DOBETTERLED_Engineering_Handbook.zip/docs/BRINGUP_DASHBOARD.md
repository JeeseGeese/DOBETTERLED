# DOBETTERLED Bring-Up Dashboard

## Purpose

The Bring-Up Dashboard is the permanent engineering interface for DOBETTERLED.

It exists to answer:

> Is the hardware working right now?

Before debugging animations, settings, sound, or button logic, first confirm the dashboard works.

## Confirmed Dashboard Functions

Current dashboard supports:

```text
1 = Solid Red
2 = Solid Green
3 = Solid Blue
4 = Solid White
5 = Moving Rainbow
6 = Chase Test
7 = Relay Off Test
8 = Button Test
9 = LEDs Off
+ = Brightness Up
- = Brightness Down
m = Print Menu Again
```

## How to Use

1. Open the PlatformIO project in VS Code.
2. Build with the checkmark icon.
3. Upload with the right-arrow icon.
4. Open Serial Monitor with the plug icon.
5. Type a command and press Enter.

## Visual Workflow

```text
VS Code Bottom Bar

✔  Build
→  Upload
🔌 Serial Monitor
```

## Why This Matters

Without the dashboard, every failure looks the same:

```text
No LEDs
```

That could mean:

- bad wiring
- wrong pin
- wrong LED count
- relay off
- bad code
- settings loaded off
- animation bug
- power issue

With the dashboard:

```text
Dashboard works → hardware is fine
Dashboard fails → hardware or low-level driver issue
```

## Rule

If a future feature breaks LED output, return to the dashboard before debugging higher-level code.

## Future Dashboard Additions

Planned v0.2.0 dashboard improvements:

- Live button state
- Single/double/triple/quad press reporting
- Hold duration display
- Brightness delta display
- Factory reset warning timer
- Free heap display
- FPS display
- Firmware version printout
- Current mode display
- Audio level meter
