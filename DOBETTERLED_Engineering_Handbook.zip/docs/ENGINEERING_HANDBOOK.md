# DOBETTERLED Engineering Handbook

## Project Mission

DOBETTERLED is an open-source ESP32 LED firmware platform for festival LEDs, totems, flow art, wearables, and experimental LED products.

The goal is not to create another messy LED sketch. The goal is to build a reusable firmware foundation that can grow into multiple products without turning into spaghetti-code hell.

## Current Status

**Current milestone:** v0.1.0-alpha — Hardware Bring-Up Complete

Confirmed working:

- PlatformIO workflow
- Dig2Go hardware target
- ESP32 upload over USB-C / CH340
- GPIO16 LED data output
- GPIO12 LED relay control
- 15 WS2812B LEDs
- GRB color order
- FastLED output
- Serial Bring-Up Dashboard
- Basic brightness and color tests

## Core Engineering Rules

1. Hardware bring-up before features.
2. PlatformIO is the primary development environment.
3. Arduino IDE may be used only for quick isolation sketches.
4. Every new subsystem must be testable from the Bring-Up Dashboard.
5. No feature creep before Beta 1.
6. GitHub commits should be small and meaningful.
7. Every stable milestone should become a GitHub Release.
8. If hardware breaks, return to the Bring-Up Dashboard before debugging higher-level firmware.
9. If a simple test works but the architecture does not, diff the working test against the architecture.
10. Make it work, make it reliable, make it fast, then make it look fucking awesome.

## Development Style

DOBETTERLED should be built like a real embedded product:

- Modular
- Testable
- Non-blocking
- Hardware-abstracted
- Documented
- Versioned
- Field-tested

## Preferred Workflow

```text
Small Feature
    ↓
Build
    ↓
Upload
    ↓
Test in Bring-Up Dashboard
    ↓
Commit
    ↓
Document
    ↓
Release if milestone-worthy
```

## Current Hardware Target

QuinLED Dig2Go:

- ESP32
- USB-C CH340 serial
- LED data: GPIO16
- LED relay: GPIO12, active HIGH
- LED count: 15
- LED type: WS2812B
- Color order: GRB
- Button: GPIO0, active LOW
- Mic: Dig2Go onboard I2S mic, future milestone

## Project Identity

Short repo description:

> Open-source ESP32 firmware for festival LEDs, totems, and flow art. Currently in active development and field testing—expect bugs, expect updates, expect cool shit.

## Beta 1 Goal

Beta 1 is complete when the firmware can be handed to another person and they can:

- Flash it
- Power it up
- Use the button without instructions
- Change effects
- Adjust brightness
- Toggle power
- Use sound mode
- Recover/reset if needed
- Report bugs clearly

Beta 1 is not about having 50 effects. It is about having a reliable and fun product experience.
