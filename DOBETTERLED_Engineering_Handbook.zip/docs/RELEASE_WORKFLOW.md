# DOBETTERLED Release Workflow

## Versioning

Use semantic-ish versioning with development labels:

```text
v0.1.0-alpha
v0.2.0-alpha
v0.7.0-beta
v1.0.0
```

## Release Types

### Alpha

Engineering milestone. May break. Used for development and field testing.

### Beta

Feature-complete enough for external testers. Bugs expected, but UX should be coherent.

### Stable

Production-quality release candidate.

## Release Checklist

Before creating a GitHub release:

- [ ] Project builds successfully in PlatformIO
- [ ] Firmware uploads successfully
- [ ] Bring-Up Dashboard passes
- [ ] Confirmed on real Dig2Go hardware
- [ ] README updated
- [ ] CHANGELOG updated
- [ ] Known issues documented
- [ ] Version number updated
- [ ] Git commit pushed

## First Release Recommendation

Create:

```text
v0.1.0-alpha
DOBETTERLED v0.1.0-alpha — Hardware Bring-Up
```

Release notes:

```markdown
# DOBETTERLED v0.1.0-alpha

First public engineering release.

## Working

- PlatformIO project
- ESP32 support
- Dig2Go support
- WS2812B LEDs
- GPIO16 LED output
- GPIO12 relay control
- Bring-Up Dashboard
- Serial diagnostics

## Status

This is an alpha release intended for development and field testing.

Expect bugs. Expect updates. Expect cool shit.
```

## GitHub Release Flow

```text
GitHub repo
    ↓
Releases
    ↓
Draft a new release
    ↓
Create new tag
    ↓
Publish release
```
