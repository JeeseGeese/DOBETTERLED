# DOBETTERLED Roadmap

## v0.1.0-alpha — Hardware Bring-Up

Status: Complete

- PlatformIO migration
- Dig2Go support
- LED output confirmed
- Relay confirmed
- 15 WS2812B LEDs confirmed
- GRB confirmed
- Bring-Up Dashboard working

## v0.2.0-alpha — Interactive Bring-Up

Goal: integrate physical button diagnostics into the dashboard.

Tasks:

- [ ] Button raw state display
- [ ] Single click detection
- [ ] Double click detection
- [ ] Triple click detection
- [ ] Quad click detection
- [ ] Long press detection
- [ ] Hold duration
- [ ] Brightness ramp intent
- [ ] Factory reset warning
- [ ] Serial status dashboard

## v0.3.0-alpha — Settings Persistence

Goal: bring back persistent user settings safely.

Tasks:

- [ ] Brightness persistence
- [ ] Power state persistence
- [ ] Animation ID persistence
- [ ] Palette ID persistence
- [ ] Audio mode persistence
- [ ] Dirty-flag NVS writes
- [ ] Factory reset clears settings

## v0.4.0-alpha — Animation Engine

Goal: restore modular effect system.

Tasks:

- [ ] AnimationBase
- [ ] EffectRegistry
- [ ] AnimationManager
- [ ] SolidEffect
- [ ] RainbowEffect
- [ ] ChaseEffect
- [ ] SparkleEffect

## v0.5.0-alpha — Product UX

Goal: make the firmware feel like a product.

Tasks:

- [ ] Startup behavior
- [ ] Shutdown behavior
- [ ] Smooth brightness changes
- [ ] Power toggle
- [ ] Palette cycling
- [ ] Visual feedback

## v0.6.0-alpha — Sound Bring-Up

Goal: validate Dig2Go microphone and audio processing.

Tasks:

- [ ] I2S mic init
- [ ] raw level diagnostics
- [ ] noise floor calibration
- [ ] envelope detection
- [ ] beat detection
- [ ] audio overlay mode
- [ ] dedicated sound effect mode

## v0.7.0-beta — Field Test Candidate

Goal: firmware ready for real-world testing.

Tasks:

- [ ] button UX stable
- [ ] no random resets
- [ ] brightness reliable
- [ ] settings reliable
- [ ] effects stable
- [ ] field testing checklist
- [ ] bug report template

## v1.0.0 — First Stable Release

Goal: stable product-quality firmware.

No new features. Bug fixes and polish only.
