# DOBETTERLED Architecture

## Architecture Philosophy

DOBETTERLED separates hardware, behavior, state, and visual output into clean layers.

```text
User Interaction
      ↓
SystemManager
      ↓
Managers
      ↓
HAL
      ↓
Physical Hardware
```

## Layer Responsibilities

### SystemManager

The application coordinator.

Responsible for:

- Boot sequence
- Runtime update loop
- Mapping button events to actions
- Frame pacing
- Calling manager update methods
- Applying settings to hardware-facing managers

SystemManager may know about all managers, but it should not directly manipulate GPIO, FastLED, or low-level hardware.

### HAL

Hardware Abstraction Layer.

Responsible for:

- pinMode
- digitalRead
- digitalWrite
- raw button state
- raw relay control
- raw mic/I2S access

HAL never knows about:

- animations
- palettes
- button gestures
- settings
- factory reset
- brightness behavior
- audio modes

### LEDDriver

Owns LED output.

Responsible for:

- FastLED setup
- pixel buffer
- brightness
- show()
- fill()
- setPixel()
- clear()
- relay-aware LED power control

Only LEDDriver should include FastLED.

### ButtonManager

Turns raw button state into button events.

Responsible for:

- debounce
- single/double/triple/quad click detection
- long press phases
- hold detection
- brightness ramp intent
- factory reset warning/request timing

ButtonManager does not decide what the events mean. SystemManager does.

### SettingsManager

Owns persistent user settings.

Responsible for:

- brightness
- current animation
- current palette
- power state
- audio mode
- primary/secondary colors
- dirty-flag debounced NVS writes

SettingsManager does not control hardware.

### AnimationManager

Responsible for:

- active animation selection
- next/previous animation
- selecting by ID
- invoking active effect
- handling dedicated audio effect override

AnimationManager does not read buttons or write settings.

### EffectRegistry

A lookup table for effects.

Responsible for:

- registering effects
- returning effect instances by AnimationId

It owns no behavior.

### PaletteManager

Responsible for:

- built-in palette definitions
- color interpolation
- palette lookup

PaletteManager owns no current state.

### SoundManager

Future module.

Responsible for:

- microphone sampling
- noise floor calibration
- automatic gain
- volume envelope
- beat detection
- bass/volume accessors

Effects should consume processed audio values, not raw microphone data.

## Current Bring-Up Reality

The current stable hardware foundation is the Bring-Up Dashboard. Full architecture reintegration should proceed one subsystem at a time.

Do not re-enable the entire architecture at once. Add layers back gradually:

1. LEDDriver
2. HAL relay abstraction
3. ButtonManager
4. SettingsManager
5. AnimationManager
6. Effects
7. SoundManager
8. Transitions
