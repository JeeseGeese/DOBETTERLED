# DOBETTERLED Documentation Package

Copy the `docs/` folder into the root of your DOBETTERLED GitHub repository.

Recommended next commit:

```bash
git add docs
git commit -m "Add DOBETTERLED engineering handbook"
git push
```

These docs establish the development workflow, architecture rules, release process, roadmap, and AI assistant context for future DOBETTERLED sessions.
